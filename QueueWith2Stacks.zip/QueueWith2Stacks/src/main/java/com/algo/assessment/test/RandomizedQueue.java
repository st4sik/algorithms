

import edu.princeton.cs.algs4.StdRandom;
import java.util.Iterator;
import java.util.NoSuchElementException;
public class RandomizedQueue<Item> implements Iterable<Item> {

	private Item[] items;
	private int n;

	public RandomizedQueue() {
		this.items = (Item[]) new Object[1];
	}

	public boolean isEmpty() {
		return n == 0;
	}

	public int size() {
		return n;
	}

	public void enqueue(Item item) {
		if (item == null) {
			throw new IllegalArgumentException();
		}
		if (n == items.length) {
			resize(2 * items.length);
		}
		items[n] = item;
		n++;
	}

	public Item dequeue() {
		if (n == 0) {
			throw new NoSuchElementException();
		}

		int rand = StdRandom.uniform(n);
		Item item = items[rand];

		if (size() - 1 == n) {
			items[rand] = null;
		} else {
			items[rand] = items[n - 1];
			items[n - 1] = null;
		}
		if (n == items.length / 4) {
			resize(items.length / 4);
		}
		n--;
		return item;
	}

	public Item sample() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		return items[StdRandom.uniform(n)];
	}

	private void resize(int capacity) {
		Item[] copy = (Item[]) new Object[capacity];

		for (int i = 0; i < items.length; i++) {
			copy[i] = items[i];
		}
		items = copy;
	}

	@Override
	public Iterator<Item> iterator() {
		return new RandomQueueIterator();
	}

	private class RandomQueueIterator implements Iterator<Item> {

		private int[] ids;
		private int i;


		public RandomQueueIterator() {
			ids = new int[n];

			for (int i = 0; i < n; i++) {
				ids[i] = i;
			}

			StdRandom.shuffle(ids);
		}

		@Override
		public boolean hasNext() {
			return i < n;
		}

		@Override
		public Item next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			return items[ids[i++]];
		}
	}
}
