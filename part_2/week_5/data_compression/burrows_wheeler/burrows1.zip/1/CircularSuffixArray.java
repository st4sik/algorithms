import edu.princeton.cs.algs4.MSD;
import edu.princeton.cs.algs4.Quick3way;
import java.util.HashSet;
import java.util.Set;

public class CircularSuffixArray {

  private static final int R = 256;
  private static final int M = 30;
  private final int N;
  private int[] index;
  private OffsetString[] aux;

  public CircularSuffixArray(String s) {
    if (s == null && s.isEmpty()) {
      throw new IllegalArgumentException();
    }
    this.N = s.length();
    this.index = new int[N];
    Set<Character> alphabet = new HashSet<>();
    OffsetString[] suffix = new OffsetString[N];
    for (int offset = 0; offset < N; offset++) {
      suffix[offset] = new OffsetString(s, offset);
      alphabet.add(s.charAt(offset));
    }
    Quick3way.sort(suffix);

    for (int i = 0; i < N; i++) {
      index[i] = suffix[i].getOffset();
    }

  }

  public int length() {
    return N;
  }

  public int index(int i) {
    if (i < 0 || i >= N) {
      throw new IllegalArgumentException();
    }
    return index[i];
  }


  private class OffsetString implements Comparable<OffsetString> {

    private final int N;
    private final String str;
    private final int offset;

    public OffsetString(String str, int offset) {
      this.str = str;
      this.N = str.length();
      this.offset = offset;
    }

    public int getOffset() {
      return offset;
    }

    @Override
    public int compareTo(OffsetString that) {
      for (int i = 0; i < N; i++) {
        int diff = this.charAt(i) - that.charAt(i);
        if (diff != 0) {
          return diff;
        }
      }
      return 0;
    }

    private int charAt(int i) {
      if (i >= N) {
        return 0;
      }
      return str.charAt((i + offset) % N);
    }
  }

    public static void main(String[] args) {
      CircularSuffixArray c = new CircularSuffixArray("ABRACADABRA!");
      for (int i = 0; i < c.length(); i++)
        System.out.print(c.index(i) + " ");
    }
}
