import edu.princeton.cs.algs4.BinaryStdIn;
import edu.princeton.cs.algs4.BinaryStdOut;
import java.util.LinkedList;
import java.util.List;

public class MoveToFront {

  private static final int R = 256;
  private static final String PLUS = "+";
  private static final String MINUS = "-";
  private static final int BIT = 8;

  public static void encode() {
    List<Integer> alphabet = new LinkedList<>();
    for (int i = 0; i < R; i++) {
      alphabet.add(i);
    }

    while (!BinaryStdIn.isEmpty()) {
      int c = BinaryStdIn.readChar();
      int index = alphabet.indexOf(c);
      BinaryStdOut.write(index, BIT);

      alphabet.remove(index);
      alphabet.add(0, c);
    }
    BinaryStdOut.close();
  }

  public static void decode() {
    List<Integer> alphabet = new LinkedList<>();
    for (int i = 0; i < R; i++) {
      alphabet.add(i);
    }

    while (!BinaryStdIn.isEmpty()) {
      int index = BinaryStdIn.readChar();
      int c = alphabet.get(index);
      BinaryStdOut.write(c, BIT);

      alphabet.remove(index);
      alphabet.add(0, c);
    }
    BinaryStdOut.close();

  }

  public static void main(String[] args) {
    if (args.length == 0) {
      return;
    }
    if (MINUS.equals(args[0])) {
      encode();
    } else if (PLUS.equals(args[0])) {
      decode();
    }
  }
}
